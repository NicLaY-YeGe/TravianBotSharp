﻿using MainCore.UI.ViewModels.Tabs.Villages;
using ReactiveUI;
using System.Reactive.Disposables.Fluent;

namespace WPFUI.Views.Tabs.Villages
{
    public class VillageSettingTabBase : ReactiveUserControl<VillageSettingViewModel>
    {
    }

    /// <summary>
    /// Interaction logic for VillageSettingTab.xaml
    /// </summary>
    public partial class VillageSettingTab : VillageSettingTabBase
    {
        public VillageSettingTab()
        {
            InitializeComponent();
            this.WhenActivated(d =>
            {
                this.BindCommand(ViewModel, vm => vm.ExportCommand, v => v.ExportButton).DisposeWith(d);
                this.BindCommand(ViewModel, vm => vm.ImportCommand, v => v.ImportButton).DisposeWith(d);
                this.BindCommand(ViewModel, vm => vm.SaveCommand, v => v.SaveButton).DisposeWith(d);

                this.Bind(ViewModel, vm => vm.VillageSettingInput.UseHeroResourceForBuilding, v => v.UseHeroResForBuilding.IsChecked).DisposeWith(d);
                this.Bind(ViewModel, vm => vm.VillageSettingInput.ApplyRomanQueueLogicWhenBuilding, v => v.UseRomanQueueLogic.IsChecked).DisposeWith(d);
                this.Bind(ViewModel, vm => vm.VillageSettingInput.UseSpecialUpgrade, v => v.UseSpecialUpgrade.IsChecked).DisposeWith(d);
                this.Bind(ViewModel, vm => vm.VillageSettingInput.CompleteImmediately, v => v.CompleteImmediately.IsChecked).DisposeWith(d);
                this.Bind(ViewModel, vm => vm.VillageSettingInput.CompleteImmediatelyTime, v => v.CompleteImmediatelyTime.Text).DisposeWith(d);

                this.Bind(ViewModel, vm => vm.VillageSettingInput.Tribe, v => v.Tribes.ViewModel).DisposeWith(d);

                this.Bind(ViewModel, vm => vm.VillageSettingInput.TrainTroopEnable, v => v.TrainTroopEnable.IsChecked).DisposeWith(d);
                this.Bind(ViewModel, vm => vm.VillageSettingInput.TrainWhenLowResource, v => v.TrainWhenLowResource.IsChecked).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.TrainTroopRepeatTime, v => v.TrainTroopRepeatTime.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.BarrackTroop, v => v.BarrackTroop.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.BarrackAmount, v => v.BarrackAmount.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.StableTroop, v => v.StableTroop.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.StableAmount, v => v.StableAmount.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.GreatBarrackTroop, v => v.GreatBarrackTroop.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.GreatBarrackAmount, v => v.GreatBarrackAmount.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.GreatStableTroop, v => v.GreatStableTroop.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.GreatStableAmount, v => v.GreatStableAmount.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.WorkshopTroop, v => v.WorkshopTroop.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.WorkshopAmount, v => v.WorkshopAmount.ViewModel).DisposeWith(d);

                this.Bind(ViewModel, vm => vm.VillageSettingInput.TrapEnable, v => v.TrapEnable.IsChecked).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.TrapRepeatTime, v => v.TrapRepeatTime.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.TrapAmount, v => v.TrapAmount.ViewModel).DisposeWith(d);

                this.Bind(ViewModel, vm => vm.VillageSettingInput.CropScanEnable, v => v.CropScanEnable.IsChecked).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.CropScanCenterX, v => v.CropScanCenterX.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.CropScanCenterY, v => v.CropScanCenterY.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.CropScanMaxDistance, v => v.CropScanMaxDistance.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.CropScanMinCroplands, v => v.CropScanMinCroplands.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.CropScanGap, v => v.CropScanGap.ViewModel).DisposeWith(d);

                this.Bind(ViewModel, vm => vm.VillageSettingInput.AutoNPCEnable, v => v.AutoNPCEnable.IsChecked).DisposeWith(d);
                this.Bind(ViewModel, vm => vm.VillageSettingInput.AutoNPCOverflow, v => v.AutoNPCOverflow.IsChecked).DisposeWith(d);
                this.Bind(ViewModel, vm => vm.VillageSettingInput.AutoNPCReverse, v => v.AutoNPCReverse.IsChecked).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.AutoNPCGranaryPercent, v => v.AutoNPCGranaryPercent.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.AutoNPCRatio, v => v.AutoNPCRatio.ViewModel).DisposeWith(d);

                this.Bind(ViewModel, vm => vm.VillageSettingInput.AutoSendCropEnable, v => v.AutoSendCropEnable.IsChecked).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.AutoSendCropGranaryPercent, v => v.AutoSendCropGranaryPercent.ViewModel).DisposeWith(d);
                this.Bind(ViewModel, vm => vm.VillageSettingInput.AutoSendCropSourceEnable, v => v.AutoSendCropSourceEnable.IsChecked).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.AutoSendCropReservePercent, v => v.AutoSendCropReservePercent.ViewModel).DisposeWith(d);

                this.Bind(ViewModel, vm => vm.VillageSettingInput.AutoBalanceEnable, v => v.AutoBalanceEnable.IsChecked).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.AutoBalanceOverflowPercent, v => v.AutoBalanceOverflowPercent.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.AutoBalanceTargetPercent, v => v.AutoBalanceTargetPercent.ViewModel).DisposeWith(d);

                this.Bind(ViewModel, vm => vm.VillageSettingInput.DodgeEnable, v => v.DodgeEnable.IsChecked).DisposeWith(d);
                this.Bind(ViewModel, vm => vm.VillageSettingInput.DefendDonateEnable, v => v.DefendDonateEnable.IsChecked).DisposeWith(d);
                this.Bind(ViewModel, vm => vm.VillageSettingInput.DodgeRaidEnable, v => v.DodgeRaidEnable.IsChecked).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.DodgeTroopSlots.Items, v => v.DodgeTroopItems.ItemsSource).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.DodgeTargetX, v => v.DodgeTargetX.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.DodgeTargetY, v => v.DodgeTargetY.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.DodgeSendSecondsBeforeImpact, v => v.DodgeSendSecondsBeforeImpact.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.DodgeRecallSecondsAfterSend, v => v.DodgeRecallSecondsAfterSend.ViewModel).DisposeWith(d);

                this.Bind(ViewModel, vm => vm.VillageSettingInput.AutoSettleEnable, v => v.AutoSettleEnable.IsChecked).DisposeWith(d);
                this.Bind(ViewModel, vm => vm.VillageSettingInput.AutoApplyBuildTemplateEnable, v => v.AutoApplyBuildTemplateEnable.IsChecked).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.AutoSettleTargetX, v => v.AutoSettleTargetX.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.AutoSettleTargetY, v => v.AutoSettleTargetY.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.AutoSettleSettlersReady, v => v.AutoSettleSettlersReady.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.ExpansionSupplyReservePercent, v => v.ExpansionSupplyReservePercent.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.ReviveSupplyReservePercent, v => v.ReviveSupplyReservePercent.ViewModel).DisposeWith(d);

                this.Bind(ViewModel, vm => vm.VillageSettingInput.SmithyUpgradeEnable, v => v.SmithyUpgradeEnable.IsChecked).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.SmithyUpgradeTroopSlot, v => v.SmithyUpgradeTroopSlot.ViewModel).DisposeWith(d);

                this.Bind(ViewModel, vm => vm.VillageSettingInput.DemolishEnable, v => v.DemolishEnable.IsChecked).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.DemolishSourceLocation, v => v.DemolishSourceLocation.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.DemolishTargetBuildingType, v => v.DemolishTargetBuildingType.ViewModel).DisposeWith(d);

                this.Bind(ViewModel, vm => vm.VillageSettingInput.SupplyFromHammerEnable, v => v.SupplyFromHammerEnable.IsChecked).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.SupplyFromHammerTargetPercent, v => v.SupplyFromHammerTargetPercent.ViewModel).DisposeWith(d);

                this.Bind(ViewModel, vm => vm.VillageSettingInput.SmallCelebrationEnable, v => v.SmallCelebrationEnable.IsChecked).DisposeWith(d);

                this.Bind(ViewModel, vm => vm.VillageSettingInput.OverflowToHammerEnable, v => v.OverflowToHammerEnable.IsChecked).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.OverflowToHammerPercent, v => v.OverflowToHammerPercent.ViewModel).DisposeWith(d);

                this.Bind(ViewModel, vm => vm.VillageSettingInput.AutoRefreshEnable, v => v.AutoRefreshEnable.IsChecked).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.AutoRefreshTime, v => v.AutoRefreshTime.ViewModel).DisposeWith(d);

                this.Bind(ViewModel, vm => vm.VillageSettingInput.EnableOasisScout, v => v.EnableOasisScout.IsChecked).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.OasisScoutMaxDistance, v => v.OasisScoutMaxDistance.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.OasisScoutIntervalMin, v => v.OasisScoutIntervalMin.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.OasisScoutIntervalMax, v => v.OasisScoutIntervalMax.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.OasisScoutTroopSlot, v => v.OasisScoutTroopSlot.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.OasisScoutMinTroops, v => v.OasisScoutMinTroops.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.OasisScoutMaxTroops, v => v.OasisScoutMaxTroops.ViewModel).DisposeWith(d);
                this.OneWayBind(ViewModel, vm => vm.VillageSettingInput.OasisScoutHeroPowerThreshold, v => v.OasisScoutHeroPowerThreshold.ViewModel).DisposeWith(d);

                this.Bind(ViewModel, vm => vm.VillageSettingInput.AutoClaimQuestEnable, v => v.AutoClaimQuestEnable.IsChecked).DisposeWith(d);
            });
        }
    }
}