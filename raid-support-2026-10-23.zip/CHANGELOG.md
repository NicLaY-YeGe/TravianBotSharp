# CHANGELOG.md — TravianBotSharp (Playwright branch)

Newest first. "Verification" says how far a change got: static (read/checked only), built (CI green), live (user ran it).

## 2026-10-23 — Defensive tasks understand RAIDS; no more silent skips (code, NOT yet built or tested live)

Log 2026-10-22 16:12-19:50: Dodge + Defend started 14 times in TS-3202 and every time ended with a silent skip, so the
donation, Dodge and Recall were never exercised. Real Rally Point Overview captures (2026-10-23) show the cause class:
hostile incoming movements are two table types - `troop_details inAttack` ("X attacks Y") and `troop_details inRaid`
("X raids Y"); the countdown markup (`span.timer value=`) is identical. The old parser read only `inAttack`, while the
village "under attack" flag (dorf movements widget, `att*` icon) is also on for raids. A village that was only raided
therefore looked attacked but had "no attack" on the page. (Consistent with the log; the 10-22 page itself was never
captured, so this is the best explanation, not proof.)
- `Parsers/RallyPointOverviewParser.cs`: `IncomingKind {Attack, Raid}`, `IncomingMovement(Kind, Seconds, Headline)`,
  `GetIncomingMovements`, `GetIncomingHostileSeconds(doc, includeRaids)`; `GetIncomingAttackSeconds` unchanged (attacks only).
- `Tasks/DefendDonateTask.cs`: reacts to attacks AND raids (soonest movement); log says which kind.
- `Tasks/DodgeTroopTask.cs`: attacks always; raids only if the new village setting `DodgeRaidEnable` is on (default OFF,
  appended last to `VillageSettingEnums`; checkbox in the Village Setting tab; backfilled by `FillVillageSettings`).
  Defend's time budget only holds Dodge's send moment when Dodge will really react to that movement.
- `Commands/Features/DodgeTroop/IncomingMovementDiagnostics.cs` (new): when the flag is on but there is nothing to react
  to, the task now logs what the page really contained (or a warning "flagged but no incoming attack or raid") and saves
  the page via `PageDump` (at most once per village per 30 min).
- Tests: `RallyPointOverviewParser.Test.cs` + fixture `Parsers/RallyPointOverview/IncomingRaidAndAttack.html` (real capture:
  raid in 569 s + attack in 2364 s). Note the captured raid came from the user's OWN village (TS-3201, probably a test); an
  enemy raid should have the same classes with "?" troop counts (not seen yet).
- Not changed: the donation still has no live proof (TODO P0). Telegram text still says "saldiri".
- Verification: static only (brace balance, signature cross-check; no dotnet in the sandbox).

## 2026-10-22 (afternoon) — Defend: train cheapest troop, then donate everything left to the alliance Recruitment bonus (code, NOT yet built or tested live)

User decision (after the live-log review): on attack detection, once per attack: train the cheapest troop, donate ALL
remaining resources to the alliance's Recruitment bonus. Daily limit used up -> the rest stays in the village (no
merchant fallback). Single donation at detection. Reason: the Marketplace send never ran in 3 live attacks (17:47,
07:45, 11:06 all "No free merchants in 55031").
- `Tasks/DefendDonateTask.cs`: merchant steps removed; step 3 = `DonateAllianceBonusCommand` with its own 60 s cap
  (`DonationTimeoutSeconds`) inside the existing time budget; any failure is Skip; log line
  `Defend done … donated X of Y resources to the alliance Recruitment bonus`.
- `Commands/Features/DefendDonate/DonateAllianceBonusCommand.cs` rewritten against two real captures of
  `/alliance/bonuses`: clicks the bonus LABEL (the radio input may be hidden — prime suspect for the 2026-09-27 180 s
  hang, unproven), types amounts by id, waits max 10 s for the Contribute button to lose its `disabled` class (the game
  never really disables it; clicking while "disabled" silently does nothing), clicks it, then waits max 8 s for
  `donatedToday` to rise or the response text to appear. No sign -> logged as UNCONFIRMED (warning + page dump), not as
  failure. Any failure saves page HTML + screenshot. Optional `TimeoutSeconds` bounds the whole command.
- `Parsers/AllianceBonusParser.cs`: `GetRecruitmentBonusLabel`, `IsContributeEnabled`, `IsDailyLimitReached`,
  `GetDonatedToday`, `GetDonationResponseText`.
- `Services/PageDump.cs` (new): shared "save page HTML + screenshot to `Screenshots/`" helper.
- Tests: `MainCore.Test/Parsers/AllianceBonusParserTest.cs` + two real fixtures in `Parsers/AllianceBonus/`.
- 2026-10-22 14:50: a third real capture (form filled in, `Bonuses_Filled.html`) CONFIRMS the proof used by the command: with a bonus selected and amounts typed, `#donate_green` has no `disabled` class and `#donateSum` shows the typed total (321). New `GetDonateSum`; the command logs a warning if the page's sum differs from what it typed. The page also has per-resource `fillUp(...)` links ("max" next to each input) — an alternative to typing, not used. Still no capture of a FINISHED donation.
- 2026-10-22 14:52: the user's snippet right after a REAL donation of 321 shows the visible daily counter `span.donationValueNumber` going 0 -> 321 (of 1,650,000): the donation worked by hand and this counter is a confirmed success signal. New `GetDonatedTodayShown`; the command now treats the hidden `donatedToday`, the visible counter or the response text as confirmation. Whether the hidden input and `.bonus-donation-response` also update is still unknown.
- Findings from the captures: daily limit is 1,650,000 per player, so "limit reached" is unlikely to bind; per-resource
  maximum on the page = the active village's stock; `donate1..4` = wood, clay, iron, crop. Both captures show a fresh
  page (nothing selected, donated 0); **no capture of a finished donation exists** — the success signal is a guess.
- Unchanged: `SendResourceCommand`/`DefendResourceTargetRules` stay in the repo (used by other tasks / tests).
- Verification: static only (brace balance, signatures cross-checked; no dotnet in the sandbox).

## 2026-10-22 (10:36) — fix: Account Setting tab threw a cross-thread UI exception

Live log 10:35:59: `InvalidOperationException: The calling thread cannot access this object because a different
thread owns it` when opening the Account Setting tab. Cause: `AccountSettingViewModel.Load` runs on the task pool
(tab activation uses `ObserveOn(RxApp.TaskpoolScheduler)`) and set the four `[Reactive]` Telegram properties there;
the view two-way binds them, so ReactiveUI read the control's `ViewModel` from a non-UI thread. Fix: those four
assignments now run via `RxApp.MainThreadScheduler.Schedule`. File: `MainCore/UI/ViewModels/Tabs/AccountSettingViewModel.cs`.
Verification: static only. The other tab `Load` overrides were not audited (TODO P2).

## 2026-10-22 — fix: troop sends hung on element lookup (code, NOT yet built or tested live)

Cause (likely, from the 2026-10-21 log + code; no DOM capture yet): `SendTroopsCommand` located its form elements
with the raw positional `node.XPath`, so any shifted element made `GetElement` wait the full 180 s.
- `Commands/Features/SyncAttack/SendTroopsCommand.cs`: troop inputs by `input[name="troop[tN]"]`, event type by
  `input[name="eventType"][value="N"]`, X/Y/Send/Confirm by `StableXPath()`. New optional
  `Command.TimeoutSeconds` (hard limit for the whole send, linked CancellationTokenSource). On a timeout (own limit
  or a 180 s `GetElement` wait) it saves the page HTML + screenshot to `Screenshots/` and logs the paths; own-limit
  timeout returns `Skip`. A user pause is passed through untouched.
- `Tasks/DodgeTroopTask.cs`: send limited to `seconds-to-impact − 2` (skips if < 5 s); a failed send now logs a
  warning and returns `Skip` (no Retry holding the queue, no Recall queued without a movement); pause → `Cancel`.
- `Tasks/OasisScoutTask.cs`: oasis sends limited to 60 s (a stalled send is skipped, the loop moves on).
- `DefendDonateTask` + `SendResourceParser.GetMerchantsRawText`: when Defend skips with "No free merchants" it now logs the raw merchant block text and URL, so a parser false-negative can be told from a truly empty marketplace. No behaviour change.
- Same raw-XPath → `StableXPath()` fix in 7 more files: `ExploreAdventureCommand`, `HoldCelebrationCommand`,
  `ClaimQuestCommand` (2), `NpcExchangeToTargetCommand`, `NpcResourceCommand`, `SmithyUpgradeCommand`,
  `HandleUpgradeCommand`. No raw `By.XPath(x.XPath)` is left in `MainCore`.
- Verification: static only (brace/paren balance, signatures cross-checked; no dotnet in the sandbox).
  Live check: see TODO.md "Verification checklist".

## 2026-10-21 (evening) — analysis session, no code changed

- Analysed the live log 17:35–17:50 and the full Playwright branch; created `CLAUDE.md`, `PROJECT_CONTEXT.md`,
  `CHANGELOG.md`, `TODO.md` for this branch (none existed in the zip).
- Findings (details in PROJECT_CONTEXT.md §6.1):
  - Dodge scheduling, attack reservation, wake window: worked.
  - Defend: training worked (95 Phalanx); resource send skipped ("No free merchants").
  - Dodge send hung at `SendTroopsCommand`; impact passed unconfirmed; Recall never queued (unverified).
  - Oasis-scout sends to (39|-4) ×2 and (38|-7) hung the same way (`By.XPath(xNode.XPath)` 180 s timeouts).
  - Likely root cause: `SendTroopsCommand` still builds locators from raw `node.XPath` (6 sites) while the
    2026-10-21 `StableXPath()` fix was applied elsewhere. Not yet proven by a DOM capture.
- Verification: static only.

## 2026-10-21 — Playwright build runs

Reported by the user ("Oldu"): browser opens and the bot works. Fixes made on the way:
- `.github/workflows/*`: `include-hidden-files: true` on every `upload-artifact` step (hidden `.playwright` driver
  folder was missing from the zip).
- CI tests: `ArchitectureTest` exemption for `Tasks/Commands.Features`; internal enum counts in AccountSetting /
  VillageSetting input tests.
- `LoginCommand` logs browser-start exceptions.
- `ChromeBrowser`: Playwright `System.TimeoutException` handled everywhere (Click skipped its Force retry, Goto
  escaped raw — live log 13:01:09 / 14:12:51).
- `HtmlNodeXPathExtensions.StableXPath()` added (id-anchored XPath) and applied to SwitchTab/SwitchVillage and
  other commands; `SwitchTabCommand` wait predicate no longer throws while the tab bar is momentarily missing
  (live log 13:01:43 etc.). **Not applied to `SendTroopsCommand` and 8 other call sites (see TODO.md P0).**
- Verification: built + live (user).

## 2026-10-18/19 — Selenium → Playwright

Full replacement behind `IChromeBrowser` (`playwright-gocu-2026-10-19.zip`): `ChromeBrowser` rewritten on
Playwright 1.60 (persistent Chromium context per account, `PlaywrightAdapters.cs`, native proxy auth, click with
actionability + forced retry, 250 ms/180 s polling). User chose Playwright's own Chromium (extensions need it) and
left replace-vs-side-by-side to Claude. `packages.lock.json` must be regenerated after the package change.

## 2026-10-19/20 — Defend rework, attack reservation

- `DefendDonateTask` reworked: once per attack, train cheapest troop with whole stock, send everything left by
  Marketplace to another own village, hard time budget so Dodge is never delayed (`DefendAttackMemory`,
  `DefendResourceTargetRules`). The earlier alliance-donate version hung 180 s on the Alliance Bonus page.
- `AttackReservationRules` / `AttackReservationStore`: 3–5 min before impact until 15 s after, only defensive and
  session tasks run; defensive tasks get queue priority (log 2026-10-20 11:30–11:31 showed Recall pushed behind
  held-back tasks).
- 2026-10-20 diagnostics line `Defend send plan …` added after an attack sent only crop=8 although ~3.8k wood and
  ~36k crop were left.

## 2026-10-03 → 10-16 (condensed)

- Wake windows: night-raid (Sync Attack checkbox, 5–10 min before/after) and incoming-attack wake (default ON, no
  sentinel check-ins).
- ScoutAutoAttackTask (auto-send after scout report); ClaimDailyQuestRewardTask.
- Design discussions only: alliance-report target finder (paused), cross-village reinforcement on attack.

## Earlier (condensed from the Selenium era)

Sync Attack, Smithy upgrade, Auto Settle, Dodge (multi-slot, recall ~50 s after send), Raid List, Map Analysis,
Oasis Scout, Trapper auto-build, Crop Oasis scan, combat-decision engine Stage A (`CombatPower`,
`CombatDecisionRules`, `ReportTroopTableParser`, `ScoutedTargetGarrison`), ClaimQuest walks all tabs/pages
(2026-09-29), cookie-consent overlay dismissal (2026-09-04…09), dispatcher/bootstrap registration fixes
(2026-09-25).
