# CLAUDE.md — TravianBotSharp (Playwright branch `PlaywrghtYGG`)

Working rules for Claude on this repo. Read this first, then `PROJECT_CONTEXT.md` (architecture + feature
reference), `TODO.md` (open work) and `CHANGELOG.md` (what changed, newest first).
Keep all four files up to date at the end of every session that changes code (see §6).

> Older code comments cite "CLAUDE.md §2e / §2l" and "PROJECT_CONTEXT.md §5m". Those point into the
> Selenium-era docs, which are NOT in this branch. The rules they refer to are restated below
> (§2e = verify the page state after a click, §2l = secondary tasks must never Retry/Stop).

## 1. What this project is

TravianBotSharp (TBS): a Windows-only WPF / .NET 8 desktop bot that automates the browser game Travian.
Stack: WPF + ReactiveUI, EF Core (SQLite), Immediate.Handlers (source-generated command/task handlers),
FluentResults, HtmlAgilityPack (page parsing), Serilog, **Microsoft.Playwright 1.60** (browser control,
replaced Selenium on 2026-10-18/19).

Projects: `MainCore` (all logic, tasks, commands, parsers, UI view-models), `WPFUI` (views/XAML only),
`MainCore.Test` (xUnit + architecture tests), `tools/pure-tests` (sandbox-only test harness, §4).

## 2. Rules that have bitten us — do not repeat

1. **Two registration places for every new Task type.** Add it to the `switch` in
   `Services/CustomServiceScopeFactory.cs` AND, if it must come back after login/Restart, to the
   conditional-add loop in `RxQueue.AccountInitHandler`. Missed 3x, duplicated once. Tasks that are
   spawned on demand (Dodge, Defend, Recall, WakeUp…) are NOT bootstrapped in RxQueue by design — they are
   queued from `UpdateStorageCommand` / `UpdateVillageListCommand` or by the task that needs them.
2. **Never look an element up by a raw HtmlAgilityPack `node.XPath`.** It is absolute and positional
   ("/html[1]/body[1]/div[3]/…"); any element inserted in front (cookie banner, extension div, re-render)
   makes the Playwright locator match nothing and `GetElement` burns its full 180 s. Use
   `node.StableXPath()` (anchors at the nearest unique id) or, better, a direct id/name selector
   (`By.Id("xCoordInput")`). Fixed everywhere in `MainCore` on 2026-10-22 (not yet live-verified, TODO.md P0); keep it that way.
3. **Verify page state after a click** (old §2e). A successful `Click` only means Playwright dispatched it,
   not that the server accepted the request. Follow clicks with an explicit `browser.Wait(...)` on the
   expected page state (this is what `SendTroopsCommand` does for the confirm page).
4. **Secondary / defensive tasks must never return Retry or Stop** (old §2l). A `Retry` result holds the
   single-threaded queue and after 3 retries pauses the whole account. Defend/Dodge side-steps return
   `Skip.Error` on any failure. Only a user pause may surface as `Cancel`.
5. **Cookie/consent overlays** intercept clicks. `DismissCookieConsentCommand` runs at the top of every
   account-task cycle; do not gate it behind `IsIngamePage`.
6. **`TaskManager.Clear()`** (called from `MainLayoutViewModel.Restart()`) wipes every task, including
   in-memory-only state, then re-bootstraps only what `RxQueue.AccountInitHandler` lists. Stateful or
   one-shot tasks not in that list die silently on Restart.
7. **Unscoped village lookups.** `context.Villages.FirstOrDefault(x => x.Id == villageId.Value)` without an
   `AccountId` filter is a latent cross-account risk (still present in ~10 places, see TODO.md P2).
8. **Playwright `System.TimeoutException` is not a `PlaywrightException`.** Every Playwright call in
   `ChromeBrowser` must handle both (fixed 2026-10-21; keep it that way when adding calls).
9. **GetElement / Wait have a 3-minute ceiling** (`Timed out after 180 seconds`). That is fine for slow
   background work and fatal for time-critical work (Dodge has ~30 s). Time-critical paths need their own
   short timeout (`SendTroopsCommand.Command.TimeoutSeconds` is the pattern) or a fast-fail.
10. **UI thread.** Tab `Load` overrides run on the task pool. Setting a `[Reactive]` property that the view binds must go
    through `RxApp.MainThreadScheduler` (command outputs are already delivered on it).
11. **"disabled" in the game's UI is usually just a CSS class**, not the `disabled` attribute: Playwright's
    `Enabled`/`GetElement` happily return the element and a click does nothing. After filling a form, wait for the
    page's own proof (class gone, value changed) instead of trusting the click.
12. **Click the label, not a styled-away input.** `GetElement` needs the element to be visible; custom radio/checkbox
    inputs often are not. Use `PageDump.SaveAsync` when a step stalls so the next report comes with evidence.
13. **A delivered zip never deletes files.** Unzip-over only adds/overwrites. Anything removed must be listed
    explicitly for `git rm`.
14. **Hostile movements come in two Rally Point table classes**: `inAttack` and `inRaid` (both flag the village as
    under attack). Never parse only one; never skip silently when the flag is on - log what the page held
    (`IncomingMovementDiagnostics`).

## 3. Task / result conventions

- Every task is a `static partial class XTask` with `[Handler]`, a nested `Task : AccountTask|VillageTask`,
  `CanStart(AppDbContext)`, and `HandleAsync(...)`. Behaviors (logging, error, village/account locking) wrap it.
- Result semantics: `Result.Ok()` = done (task reschedules itself if periodic); `Skip.Error` = give up this
  run quietly; `Retry.Error` = timer re-runs it (max 3, then account pause); `Stop.Error` = pause account;
  `Cancel.Error` = user pressed pause.
- Time-critical tasks may bypass offline hours via `BypassOnlineHours` / `WakeStart` / `WakeEnd` (wake window).
- One queue per account, single-threaded: a slow task delays everything behind it. This is why Defend has a hard
  time budget and why attack windows are "reserved" (`AttackReservationRules`).

## 4. Environment limits (Claude sandbox)

- No dotnet SDK / Windows build, nuget.org is blocked. Verification is **static**: brace/paren balance, XAML
  well-formedness, signature cross-checks, and `tools/pure-tests/run.sh` (downloads the SDK debs from the Ubuntu
  archive, compiles parsers + pure logic with a shim for xUnit/Shouldly). It does NOT cover handlers, tasks,
  EF Core, Playwright, ReactiveUI.
- The user builds via GitHub Actions (GitHub Desktop, branch `PlaywrghtYGG`, PR #1), downloads the artifact
  `TravianBotSharp-win-x64`, and live-tests. Never claim "built" or "tested live" unless the user said so.
- CI quirks: every `upload-artifact` step needs `include-hidden-files: true` (the hidden `.playwright` driver
  folder is otherwise dropped); `packages.lock.json` files must be regenerated after package changes;
  `ArchitectureTest` has an exemption for `Tasks/Commands.Features`; enum-count assertions exist in the
  AccountSetting/VillageSetting input tests — adding an enum value means updating them.

## 5. Playwright-specific notes

- `Services/ChromeBrowser.cs` keeps the old `IChromeBrowser` contract; `Services/Browser/PlaywrightAdapters.cs`
  provides `PlaywrightDriver` / `PlaywrightElement` (Selenium-shaped `FindElements`, `Displayed`, `Enabled`,
  `SendKeys`) and `SyncBridge` (sync-over-async).
- One persistent Chromium context per account (`Data/Cache/<profile>/<proxy>`), Playwright's own Chromium
  (needed for `--load-extension` of the 3 bundled .crx). Headless uses `Channel = "chromium"`.
- `Click` = normal click (10 s) then one forced retry (5 s). `Input` = Home, Shift+End, `PressSequentially`
  (real key events — the game listens to keyup). `GetElement`/`Wait` poll every 250 ms for 180 s.
- Navigation timeout 180 s; default action timeout 30 s.

## 6. Documentation duty (every session that touches code)

- `CHANGELOG.md`: add a dated entry (newest first): what, why, files, verification state (static / built / live).
- `TODO.md`: move finished items out, add new findings, keep priorities (P0 = breaks a defensive feature).
- `PROJECT_CONTEXT.md`: update the feature reference / known-gaps section for any behavior change.
- `CLAUDE.md`: add a rule only when a bug class repeats or a constraint is discovered.
- Commit messages follow `.github/instructions/copilot-commit.instructions.md`; the Understand-Anything graph in
  `.understand-anything/knowledge-graph.json` is the map of the codebase — use it instead of reading everything.

## 7. Working with the user

- The user writes Turkish; answer in Turkish, keep code, comments and these docs in English.
- Design discussions first when the user says "tartışalım/konuşalım"; code only after "yaz"/"başla".
- When the user pastes a live log, read it against the code before concluding; state clearly what the log proves
  and what it only suggests.
