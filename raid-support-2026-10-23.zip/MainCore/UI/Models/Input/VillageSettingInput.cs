﻿using MainCore.UI.ViewModels.Abstract;
using MainCore.UI.ViewModels.UserControls;

namespace MainCore.UI.Models.Input
{
    public partial class VillageSettingInput : ViewModelBase
    {
        [Reactive]
        private bool _useHeroResourceForBuilding;

        [Reactive]
        private bool _applyRomanQueueLogicWhenBuilding;

        [Reactive]
        private bool _useSpecialUpgrade;

        [Reactive]
        private bool _completeImmediately;

        public TribeSelectorViewModel Tribe { get; } = new();

        [Reactive]
        private bool _trainTroopEnable;

        [Reactive]
        private bool _trainWhenLowResource;

        public TroopSelectorViewModel BarrackTroop { get; } = new();
        public TroopSelectorViewModel StableTroop { get; } = new();
        public TroopSelectorViewModel GreatBarrackTroop { get; } = new();
        public TroopSelectorViewModel GreatStableTroop { get; } = new();
        public TroopSelectorViewModel WorkshopTroop { get; } = new();

        public RangeInputViewModel TrainTroopRepeatTime { get; } = new();
        public RangeInputViewModel BarrackAmount { get; } = new();
        public RangeInputViewModel StableAmount { get; } = new();
        public RangeInputViewModel GreatBarrackAmount { get; } = new();
        public RangeInputViewModel GreatStableAmount { get; } = new();
        public RangeInputViewModel WorkshopAmount { get; } = new();

        [Reactive]
        private bool _autoNPCEnable;

        [Reactive]
        private bool _autoNPCOverflow;

        [Reactive]
        private bool _autoNPCReverse;

        public AmountInputViewModel AutoNPCGranaryPercent { get; } = new();
        public ResourceInputViewModel AutoNPCRatio { get; } = new();

        [Reactive]
        private bool _autoSendCropEnable;

        public AmountInputViewModel AutoSendCropGranaryPercent { get; } = new();

        [Reactive]
        private bool _autoSendCropSourceEnable;

        public AmountInputViewModel AutoSendCropReservePercent { get; } = new();

        [Reactive]
        private bool _autoBalanceEnable;

        public AmountInputViewModel AutoBalanceOverflowPercent { get; } = new();

        public AmountInputViewModel AutoBalanceTargetPercent { get; } = new();

        [Reactive]
        private bool _dodgeEnable;

        public DodgeTroopSelectorViewModel DodgeTroopSlots { get; } = new();
        public AmountInputViewModel DodgeTargetX { get; } = new();
        public AmountInputViewModel DodgeTargetY { get; } = new();
        public AmountInputViewModel DodgeSendSecondsBeforeImpact { get; } = new();
        public AmountInputViewModel DodgeRecallSecondsAfterSend { get; } = new();

        [Reactive]
        private bool _defendDonateEnable;

        [Reactive]
        private bool _dodgeRaidEnable;

        [Reactive]
        private bool _autoSettleEnable;

        public AmountInputViewModel AutoSettleTargetX { get; } = new();
        public AmountInputViewModel AutoSettleTargetY { get; } = new();

        // 2026-08-26: exposed so the user can correct the bot's own tracked count when it
        // doesn't match reality - e.g. settlers trained manually or left over from before
        // AutoSettleEnable was turned on for this village never increment this counter (see
        // AutoSettleTask.cs's type comment for why it's a persisted counter, not a page
        // re-read), so without a way to edit it directly the task keeps requesting resources
        // for settlers that already physically exist, and never reaches founding.
        public AmountInputViewModel AutoSettleSettlersReady { get; } = new();

        public AmountInputViewModel ExpansionSupplyReservePercent { get; } = new();
        public AmountInputViewModel ReviveSupplyReservePercent { get; } = new();

        [Reactive]
        private bool _smithyUpgradeEnable;

        public AmountInputViewModel SmithyUpgradeTroopSlot { get; } = new();

        [Reactive]
        private bool _demolishEnable;

        public AmountInputViewModel DemolishSourceLocation { get; } = new();

        public AmountInputViewModel DemolishTargetBuildingType { get; } = new();

        [Reactive]
        private bool _supplyFromHammerEnable;

        public AmountInputViewModel SupplyFromHammerTargetPercent { get; } = new();

        [Reactive]
        private bool _smallCelebrationEnable;

        [Reactive]
        private bool _overflowToHammerEnable;

        public AmountInputViewModel OverflowToHammerPercent { get; } = new();

        [Reactive]
        private bool _autoRefreshEnable;

        public RangeInputViewModel AutoRefreshTime { get; } = new();

        [Reactive]
        private bool _autoClaimQuestEnable;

        [Reactive]
        private int _completeImmediatelyTime;

        // 2026-09-12: opt-out toggle for ApplyBuildTemplateTask (default ON) - see that
        // task's CanStart comment. Missing from the original hero-revive delivery, which
        // referenced this property in Set()/Get() and in VillageSettingTab.xaml.cs's binding
        // without ever declaring the backing reactive field - caused CS0103 at build.
        [Reactive]
        private bool _autoApplyBuildTemplateEnable;

        [Reactive]
        private bool _enableOasisScout;

        public AmountInputViewModel OasisScoutMaxDistance { get; } = new();
        public AmountInputViewModel OasisScoutIntervalMin { get; } = new();
        public AmountInputViewModel OasisScoutIntervalMax { get; } = new();
        public AmountInputViewModel OasisScoutTroopSlot { get; } = new();
        public AmountInputViewModel OasisScoutMinTroops { get; } = new();
        public AmountInputViewModel OasisScoutMaxTroops { get; } = new();
        public AmountInputViewModel OasisScoutHeroPowerThreshold { get; } = new();

        [Reactive]
        private bool _trapEnable;

        public RangeInputViewModel TrapAmount { get; } = new();
        public RangeInputViewModel TrapRepeatTime { get; } = new();

        [Reactive]
        private bool _cropScanEnable;

        public AmountInputViewModel CropScanCenterX { get; } = new();
        public AmountInputViewModel CropScanCenterY { get; } = new();
        public AmountInputViewModel CropScanMaxDistance { get; } = new();
        public AmountInputViewModel CropScanMinCroplands { get; } = new();
        public RangeInputViewModel CropScanGap { get; } = new();

        public void Set(Dictionary<VillageSettingEnums, int> settings)
        {
            var tribe = (TribeEnums)settings.GetValueOrDefault(VillageSettingEnums.Tribe);
            Tribe.Set(tribe);

            UseHeroResourceForBuilding = settings.GetValueOrDefault(VillageSettingEnums.UseHeroResourceForBuilding) == 1;
            ApplyRomanQueueLogicWhenBuilding = settings.GetValueOrDefault(VillageSettingEnums.ApplyRomanQueueLogicWhenBuilding) == 1;
            CompleteImmediately = settings.GetValueOrDefault(VillageSettingEnums.CompleteImmediately) == 1;
            UseSpecialUpgrade = settings.GetValueOrDefault(VillageSettingEnums.UseSpecialUpgrade) == 1;

            TrainTroopEnable = settings.GetValueOrDefault(VillageSettingEnums.TrainTroopEnable) == 1;
            TrainWhenLowResource = settings.GetValueOrDefault(VillageSettingEnums.TrainWhenLowResource) == 1;
            TrainTroopRepeatTime.Set(
                settings.GetValueOrDefault(VillageSettingEnums.TrainTroopRepeatTimeMin),
                settings.GetValueOrDefault(VillageSettingEnums.TrainTroopRepeatTimeMax));
            var barrackTroop = (TroopEnums)settings.GetValueOrDefault(VillageSettingEnums.BarrackTroop);
            BarrackTroop.Set(barrackTroop, BuildingEnums.Barracks, tribe);
            BarrackAmount.Set(
                settings.GetValueOrDefault(VillageSettingEnums.BarrackAmountMin),
                settings.GetValueOrDefault(VillageSettingEnums.BarrackAmountMax));
            var stableTroop = (TroopEnums)settings.GetValueOrDefault(VillageSettingEnums.StableTroop);
            StableTroop.Set(stableTroop, BuildingEnums.Stable, tribe);
            StableAmount.Set(
                settings.GetValueOrDefault(VillageSettingEnums.StableAmountMin),
                settings.GetValueOrDefault(VillageSettingEnums.StableAmountMax));
            var greatBarrackTroop = (TroopEnums)settings.GetValueOrDefault(VillageSettingEnums.GreatBarrackTroop);
            GreatBarrackTroop.Set(greatBarrackTroop, BuildingEnums.GreatBarracks, tribe);
            GreatBarrackAmount.Set(
                settings.GetValueOrDefault(VillageSettingEnums.GreatBarrackAmountMin),
                settings.GetValueOrDefault(VillageSettingEnums.GreatBarrackAmountMax));
            var greatStableTroop = (TroopEnums)settings.GetValueOrDefault(VillageSettingEnums.GreatStableTroop);
            GreatStableTroop.Set(greatStableTroop, BuildingEnums.GreatStable, tribe);
            GreatStableAmount.Set(
                settings.GetValueOrDefault(VillageSettingEnums.GreatStableAmountMin),
                settings.GetValueOrDefault(VillageSettingEnums.GreatStableAmountMax));
            var workshopTroop = (TroopEnums)settings.GetValueOrDefault(VillageSettingEnums.WorkshopTroop);
            WorkshopTroop.Set(workshopTroop, BuildingEnums.Workshop, tribe);
            WorkshopAmount.Set(
                settings.GetValueOrDefault(VillageSettingEnums.WorkshopAmountMin),
                settings.GetValueOrDefault(VillageSettingEnums.WorkshopAmountMax));

            AutoNPCEnable = settings.GetValueOrDefault(VillageSettingEnums.AutoNPCEnable) == 1;
            AutoNPCOverflow = settings.GetValueOrDefault(VillageSettingEnums.AutoNPCOverflow) == 1;
            AutoNPCReverse = settings.GetValueOrDefault(VillageSettingEnums.AutoNPCReverse) == 1;
            AutoNPCGranaryPercent.Set(settings.GetValueOrDefault(VillageSettingEnums.AutoNPCGranaryPercent));
            AutoNPCRatio.Set(
                settings.GetValueOrDefault(VillageSettingEnums.AutoNPCWood),
                settings.GetValueOrDefault(VillageSettingEnums.AutoNPCClay),
                settings.GetValueOrDefault(VillageSettingEnums.AutoNPCIron),
                settings.GetValueOrDefault(VillageSettingEnums.AutoNPCCrop));

            AutoSendCropEnable = settings.GetValueOrDefault(VillageSettingEnums.AutoSendCropEnable) == 1;
            AutoSendCropGranaryPercent.Set(settings.GetValueOrDefault(VillageSettingEnums.AutoSendCropGranaryPercent));
            AutoSendCropSourceEnable = settings.GetValueOrDefault(VillageSettingEnums.AutoSendCropSourceEnable) == 1;
            AutoSendCropReservePercent.Set(settings.GetValueOrDefault(VillageSettingEnums.AutoSendCropReservePercent));

            AutoBalanceEnable = settings.GetValueOrDefault(VillageSettingEnums.AutoBalanceEnable) == 1;
            AutoBalanceOverflowPercent.Set(settings.GetValueOrDefault(VillageSettingEnums.AutoBalanceOverflowPercent));
            AutoBalanceTargetPercent.Set(settings.GetValueOrDefault(VillageSettingEnums.AutoBalanceTargetPercent));

            DodgeEnable = settings.GetValueOrDefault(VillageSettingEnums.DodgeEnable) == 1;
            DodgeTroopSlots.Set(settings.GetValueOrDefault(VillageSettingEnums.DodgeTroopSlotsMask), tribe);
            DodgeTargetX.Set(settings.GetValueOrDefault(VillageSettingEnums.DodgeTargetX));
            DodgeTargetY.Set(settings.GetValueOrDefault(VillageSettingEnums.DodgeTargetY));
            DodgeSendSecondsBeforeImpact.Set(settings.GetValueOrDefault(VillageSettingEnums.DodgeSendSecondsBeforeImpact));
            DodgeRecallSecondsAfterSend.Set(settings.GetValueOrDefault(VillageSettingEnums.DodgeRecallSecondsAfterSend));

            DefendDonateEnable = settings.GetValueOrDefault(VillageSettingEnums.DefendDonateEnable) == 1;
            DodgeRaidEnable = settings.GetValueOrDefault(VillageSettingEnums.DodgeRaidEnable) == 1;

            AutoSettleEnable = settings.GetValueOrDefault(VillageSettingEnums.AutoSettleEnable) == 1;
            // Unset row (village never explicitly saved this) defaults to checked/enabled -
            // see ApplyBuildTemplateTask's own CanStart comment for why (opt-out toggle,
            // must not silently disable the feature for every pre-existing village).
            AutoApplyBuildTemplateEnable = settings.GetValueOrDefault(VillageSettingEnums.AutoApplyBuildTemplateEnable, 1) == 1;
            AutoSettleTargetX.Set(settings.GetValueOrDefault(VillageSettingEnums.AutoSettleTargetX));
            AutoSettleTargetY.Set(settings.GetValueOrDefault(VillageSettingEnums.AutoSettleTargetY));
            AutoSettleSettlersReady.Set(settings.GetValueOrDefault(VillageSettingEnums.AutoSettleSettlersReady));
            ExpansionSupplyReservePercent.Set(settings.GetValueOrDefault(VillageSettingEnums.ExpansionSupplyReservePercent));
            ReviveSupplyReservePercent.Set(settings.GetValueOrDefault(VillageSettingEnums.ReviveSupplyReservePercent));

            SmithyUpgradeEnable = settings.GetValueOrDefault(VillageSettingEnums.SmithyUpgradeEnable) == 1;
            SmithyUpgradeTroopSlot.Set(settings.GetValueOrDefault(VillageSettingEnums.SmithyUpgradeTroopSlot));

            DemolishEnable = settings.GetValueOrDefault(VillageSettingEnums.DemolishEnable) == 1;
            DemolishSourceLocation.Set(settings.GetValueOrDefault(VillageSettingEnums.DemolishSourceLocation));
            DemolishTargetBuildingType.Set(settings.GetValueOrDefault(VillageSettingEnums.DemolishTargetBuildingType));

            SupplyFromHammerEnable = settings.GetValueOrDefault(VillageSettingEnums.SupplyFromHammerEnable) == 1;
            SupplyFromHammerTargetPercent.Set(settings.GetValueOrDefault(VillageSettingEnums.SupplyFromHammerTargetPercent));

            SmallCelebrationEnable = settings.GetValueOrDefault(VillageSettingEnums.SmallCelebrationEnable) == 1;

            OverflowToHammerEnable = settings.GetValueOrDefault(VillageSettingEnums.OverflowToHammerEnable) == 1;
            OverflowToHammerPercent.Set(settings.GetValueOrDefault(VillageSettingEnums.OverflowToHammerPercent));

            AutoRefreshEnable = settings.GetValueOrDefault(VillageSettingEnums.AutoRefreshEnable) == 1;
            AutoRefreshTime.Set(
                settings.GetValueOrDefault(VillageSettingEnums.AutoRefreshMin),
                settings.GetValueOrDefault(VillageSettingEnums.AutoRefreshMax));

            AutoClaimQuestEnable = settings.GetValueOrDefault(VillageSettingEnums.AutoClaimQuestEnable) == 1;
            CompleteImmediatelyTime = settings.GetValueOrDefault(VillageSettingEnums.CompleteImmediatelyTime);

            EnableOasisScout = settings.GetValueOrDefault(VillageSettingEnums.EnableOasisScout) == 1;
            OasisScoutMaxDistance.Set(settings.GetValueOrDefault(VillageSettingEnums.OasisScoutMaxDistance));
            OasisScoutIntervalMin.Set(settings.GetValueOrDefault(VillageSettingEnums.OasisScoutIntervalMin));
            OasisScoutIntervalMax.Set(settings.GetValueOrDefault(VillageSettingEnums.OasisScoutIntervalMax));
            OasisScoutTroopSlot.Set(settings.GetValueOrDefault(VillageSettingEnums.OasisScoutTroopSlot));
            OasisScoutMinTroops.Set(settings.GetValueOrDefault(VillageSettingEnums.OasisScoutMinTroops));
            OasisScoutMaxTroops.Set(settings.GetValueOrDefault(VillageSettingEnums.OasisScoutMaxTroops));
            OasisScoutHeroPowerThreshold.Set(settings.GetValueOrDefault(VillageSettingEnums.OasisScoutHeroPowerThreshold));

            TrapEnable = settings.GetValueOrDefault(VillageSettingEnums.TrapEnable) == 1;
            TrapAmount.Set(
                settings.GetValueOrDefault(VillageSettingEnums.TrapAmountMin),
                settings.GetValueOrDefault(VillageSettingEnums.TrapAmountMax));
            TrapRepeatTime.Set(
                settings.GetValueOrDefault(VillageSettingEnums.TrapRepeatTimeMin),
                settings.GetValueOrDefault(VillageSettingEnums.TrapRepeatTimeMax));

            CropScanEnable = settings.GetValueOrDefault(VillageSettingEnums.CropScanEnable) == 1;
            CropScanCenterX.Set(settings.GetValueOrDefault(VillageSettingEnums.CropScanCenterX));
            CropScanCenterY.Set(settings.GetValueOrDefault(VillageSettingEnums.CropScanCenterY));
            CropScanMaxDistance.Set(settings.GetValueOrDefault(VillageSettingEnums.CropScanMaxDistance));
            CropScanMinCroplands.Set(settings.GetValueOrDefault(VillageSettingEnums.CropScanMinCroplands));
            CropScanGap.Set(
                settings.GetValueOrDefault(VillageSettingEnums.CropScanGapMinSeconds),
                settings.GetValueOrDefault(VillageSettingEnums.CropScanGapMaxSeconds));
        }

        public Dictionary<VillageSettingEnums, int> Get()
        {
            var useHeroResourceForBuilding = UseHeroResourceForBuilding ? 1 : 0;
            var applyRomanQueueLogicWhenBuilding = ApplyRomanQueueLogicWhenBuilding ? 1 : 0;
            var useSpecialUpgrade = UseSpecialUpgrade ? 1 : 0;
            var completeImmediately = CompleteImmediately ? 1 : 0;

            var tribe = (int)Tribe.Get();

            var trainTroopEnable = TrainTroopEnable ? 1 : 0;
            var trainWhenLowResource = TrainWhenLowResource ? 1 : 0;
            var (trainTroopRepeatTimeMin, trainTroopRepeatTimeMax) = TrainTroopRepeatTime.Get();
            var barrackTroop = (int)BarrackTroop.Get();
            var (barrackAmountMin, barrackAmountMax) = BarrackAmount.Get();
            var stableTroop = (int)StableTroop.Get();
            var (stableAmountMin, stableAmountMax) = StableAmount.Get();
            var greatBarrackTroop = (int)GreatBarrackTroop.Get();
            var (greatBarrackAmountMin, greatBarrackAmountMax) = GreatBarrackAmount.Get();
            var greatStableTroop = (int)GreatStableTroop.Get();
            var (greatStableAmountMin, greatStableAmountMax) = GreatStableAmount.Get();
            var workshopTroop = (int)WorkshopTroop.Get();
            var (workshopAmountMin, workshopAmountMax) = WorkshopAmount.Get();

            var autoNPCEnable = AutoNPCEnable ? 1 : 0;
            var autoNPCOverflow = AutoNPCOverflow ? 1 : 0;
            var autoNPCReverse = AutoNPCReverse ? 1 : 0;
            var autoNPCGranaryPercent = AutoNPCGranaryPercent.Get();
            var (autoNPCWood, autoNPCClay, autoNPCIron, autoNPCCrop) = AutoNPCRatio.Get();

            var autoSendCropEnable = AutoSendCropEnable ? 1 : 0;
            var autoSendCropGranaryPercent = AutoSendCropGranaryPercent.Get();
            var autoSendCropSourceEnable = AutoSendCropSourceEnable ? 1 : 0;
            var autoSendCropReservePercent = AutoSendCropReservePercent.Get();

            var autoBalanceEnable = AutoBalanceEnable ? 1 : 0;
            var autoBalanceOverflowPercent = AutoBalanceOverflowPercent.Get();
            var autoBalanceTargetPercent = AutoBalanceTargetPercent.Get();

            var dodgeEnable = DodgeEnable ? 1 : 0;
            var dodgeTroopSlotsMask = DodgeTroopSlots.Get();
            var dodgeTargetX = DodgeTargetX.Get();
            var dodgeTargetY = DodgeTargetY.Get();
            var dodgeSendSecondsBeforeImpact = DodgeSendSecondsBeforeImpact.Get();
            var dodgeRecallSecondsAfterSend = DodgeRecallSecondsAfterSend.Get();

            var defendDonateEnable = DefendDonateEnable ? 1 : 0;
            var dodgeRaidEnable = DodgeRaidEnable ? 1 : 0;

            var autoSettleEnable = AutoSettleEnable ? 1 : 0;
            var autoApplyBuildTemplateEnable = AutoApplyBuildTemplateEnable ? 1 : 0;
            var autoSettleTargetX = AutoSettleTargetX.Get();
            var autoSettleTargetY = AutoSettleTargetY.Get();
            var autoSettleSettlersReady = AutoSettleSettlersReady.Get();
            var expansionSupplyReservePercent = ExpansionSupplyReservePercent.Get();
            var reviveSupplyReservePercent = ReviveSupplyReservePercent.Get();

            var smithyUpgradeEnable = SmithyUpgradeEnable ? 1 : 0;
            var smithyUpgradeTroopSlot = SmithyUpgradeTroopSlot.Get();

            var demolishEnable = DemolishEnable ? 1 : 0;
            var demolishSourceLocation = DemolishSourceLocation.Get();
            var demolishTargetBuildingType = DemolishTargetBuildingType.Get();

            var supplyFromHammerEnable = SupplyFromHammerEnable ? 1 : 0;
            var supplyFromHammerTargetPercent = SupplyFromHammerTargetPercent.Get();

            var smallCelebrationEnable = SmallCelebrationEnable ? 1 : 0;

            var overflowToHammerEnable = OverflowToHammerEnable ? 1 : 0;
            var overflowToHammerPercent = OverflowToHammerPercent.Get();

            var autoRefreshEnable = AutoRefreshEnable ? 1 : 0;
            var (autoRefreshMin, autoRefreshMax) = AutoRefreshTime.Get();

            var autoClaimQuestEnable = AutoClaimQuestEnable ? 1 : 0;
            var completeImmediatelyTime = CompleteImmediatelyTime;

            var enableOasisScout = EnableOasisScout ? 1 : 0;
            var oasisScoutMaxDistance = OasisScoutMaxDistance.Get();
            var oasisScoutIntervalMin = OasisScoutIntervalMin.Get();
            var oasisScoutIntervalMax = OasisScoutIntervalMax.Get();
            var oasisScoutTroopSlot = OasisScoutTroopSlot.Get();
            var oasisScoutMinTroops = OasisScoutMinTroops.Get();
            var oasisScoutMaxTroops = OasisScoutMaxTroops.Get();
            var oasisScoutHeroPowerThreshold = OasisScoutHeroPowerThreshold.Get();

            var trapEnable = TrapEnable ? 1 : 0;
            var (trapAmountMin, trapAmountMax) = TrapAmount.Get();
            var (trapRepeatTimeMin, trapRepeatTimeMax) = TrapRepeatTime.Get();

            var cropScanEnable = CropScanEnable ? 1 : 0;
            var cropScanCenterX = CropScanCenterX.Get();
            var cropScanCenterY = CropScanCenterY.Get();
            var cropScanMaxDistance = CropScanMaxDistance.Get();
            var cropScanMinCroplands = CropScanMinCroplands.Get();
            var (cropScanGapMinSeconds, cropScanGapMaxSeconds) = CropScanGap.Get();

            var settings = new Dictionary<VillageSettingEnums, int>()
            {
                { VillageSettingEnums.UseHeroResourceForBuilding, useHeroResourceForBuilding },
                { VillageSettingEnums.ApplyRomanQueueLogicWhenBuilding, applyRomanQueueLogicWhenBuilding },
                { VillageSettingEnums.UseSpecialUpgrade, useSpecialUpgrade },
                { VillageSettingEnums.CompleteImmediately, completeImmediately },
                { VillageSettingEnums.Tribe, tribe },
                { VillageSettingEnums.TrainTroopEnable, trainTroopEnable },
                { VillageSettingEnums.TrainWhenLowResource, trainWhenLowResource },
                { VillageSettingEnums.TrainTroopRepeatTimeMin, trainTroopRepeatTimeMin },
                { VillageSettingEnums.TrainTroopRepeatTimeMax, trainTroopRepeatTimeMax },
                { VillageSettingEnums.BarrackTroop, barrackTroop },
                { VillageSettingEnums.BarrackAmountMin, barrackAmountMin },
                { VillageSettingEnums.BarrackAmountMax, barrackAmountMax },
                { VillageSettingEnums.StableTroop, stableTroop },
                { VillageSettingEnums.StableAmountMin, stableAmountMin },
                { VillageSettingEnums.StableAmountMax, stableAmountMax },
                { VillageSettingEnums.GreatBarrackTroop, greatBarrackTroop },
                { VillageSettingEnums.GreatBarrackAmountMin, greatBarrackAmountMin },
                { VillageSettingEnums.GreatBarrackAmountMax, greatBarrackAmountMax },
                { VillageSettingEnums.GreatStableTroop, greatStableTroop },
                { VillageSettingEnums.GreatStableAmountMin, greatStableAmountMin },
                { VillageSettingEnums.GreatStableAmountMax, greatStableAmountMax },
                { VillageSettingEnums.WorkshopTroop, workshopTroop },
                { VillageSettingEnums.WorkshopAmountMin, workshopAmountMin },
                { VillageSettingEnums.WorkshopAmountMax, workshopAmountMax },
                { VillageSettingEnums.AutoNPCEnable, autoNPCEnable },
                { VillageSettingEnums.AutoNPCOverflow, autoNPCOverflow },
                { VillageSettingEnums.AutoNPCReverse, autoNPCReverse },
                { VillageSettingEnums.AutoNPCGranaryPercent, autoNPCGranaryPercent },
                { VillageSettingEnums.AutoNPCWood, autoNPCWood },
                { VillageSettingEnums.AutoNPCClay, autoNPCClay },
                { VillageSettingEnums.AutoNPCIron, autoNPCIron },
                { VillageSettingEnums.AutoNPCCrop, autoNPCCrop },
                { VillageSettingEnums.AutoSendCropEnable, autoSendCropEnable },
                { VillageSettingEnums.AutoSendCropGranaryPercent, autoSendCropGranaryPercent },
                { VillageSettingEnums.AutoSendCropSourceEnable, autoSendCropSourceEnable },
                { VillageSettingEnums.AutoSendCropReservePercent, autoSendCropReservePercent },

                { VillageSettingEnums.AutoBalanceEnable, autoBalanceEnable },
                { VillageSettingEnums.AutoBalanceOverflowPercent, autoBalanceOverflowPercent },
                { VillageSettingEnums.AutoBalanceTargetPercent, autoBalanceTargetPercent },

                { VillageSettingEnums.DodgeEnable, dodgeEnable },
                { VillageSettingEnums.DodgeTroopSlotsMask, dodgeTroopSlotsMask },
                { VillageSettingEnums.DodgeTargetX, dodgeTargetX },
                { VillageSettingEnums.DodgeTargetY, dodgeTargetY },
                { VillageSettingEnums.DodgeSendSecondsBeforeImpact, dodgeSendSecondsBeforeImpact },
                { VillageSettingEnums.DodgeRecallSecondsAfterSend, dodgeRecallSecondsAfterSend },

                { VillageSettingEnums.DefendDonateEnable, defendDonateEnable },
                { VillageSettingEnums.DodgeRaidEnable, dodgeRaidEnable },

                { VillageSettingEnums.AutoSettleEnable, autoSettleEnable },
                { VillageSettingEnums.AutoApplyBuildTemplateEnable, autoApplyBuildTemplateEnable },
                { VillageSettingEnums.AutoSettleTargetX, autoSettleTargetX },
                { VillageSettingEnums.AutoSettleTargetY, autoSettleTargetY },
                { VillageSettingEnums.AutoSettleSettlersReady, autoSettleSettlersReady },
                { VillageSettingEnums.ExpansionSupplyReservePercent, expansionSupplyReservePercent },
                { VillageSettingEnums.ReviveSupplyReservePercent, reviveSupplyReservePercent },

                { VillageSettingEnums.SmithyUpgradeEnable, smithyUpgradeEnable },
                { VillageSettingEnums.SmithyUpgradeTroopSlot, smithyUpgradeTroopSlot },

                { VillageSettingEnums.DemolishEnable, demolishEnable },
                { VillageSettingEnums.DemolishSourceLocation, demolishSourceLocation },
                { VillageSettingEnums.DemolishTargetBuildingType, demolishTargetBuildingType },

                { VillageSettingEnums.SupplyFromHammerEnable, supplyFromHammerEnable },
                { VillageSettingEnums.SupplyFromHammerTargetPercent, supplyFromHammerTargetPercent },

                { VillageSettingEnums.SmallCelebrationEnable, smallCelebrationEnable },

                { VillageSettingEnums.OverflowToHammerEnable, overflowToHammerEnable },
                { VillageSettingEnums.OverflowToHammerPercent, overflowToHammerPercent },
                { VillageSettingEnums.AutoRefreshEnable, autoRefreshEnable },
                { VillageSettingEnums.AutoRefreshMin, autoRefreshMin },
                { VillageSettingEnums.AutoRefreshMax, autoRefreshMax },
                { VillageSettingEnums.AutoClaimQuestEnable, autoClaimQuestEnable },
                { VillageSettingEnums.CompleteImmediatelyTime, completeImmediatelyTime },

                { VillageSettingEnums.EnableOasisScout, enableOasisScout },
                { VillageSettingEnums.OasisScoutMaxDistance, oasisScoutMaxDistance },
                { VillageSettingEnums.OasisScoutIntervalMin, oasisScoutIntervalMin },
                { VillageSettingEnums.OasisScoutIntervalMax, oasisScoutIntervalMax },
                { VillageSettingEnums.OasisScoutTroopSlot, oasisScoutTroopSlot },
                { VillageSettingEnums.OasisScoutMinTroops, oasisScoutMinTroops },
                { VillageSettingEnums.OasisScoutMaxTroops, oasisScoutMaxTroops },
                { VillageSettingEnums.OasisScoutHeroPowerThreshold, oasisScoutHeroPowerThreshold },

                { VillageSettingEnums.TrapEnable, trapEnable },
                { VillageSettingEnums.TrapAmountMin, trapAmountMin },
                { VillageSettingEnums.TrapAmountMax, trapAmountMax },
                { VillageSettingEnums.TrapRepeatTimeMin, trapRepeatTimeMin },
                { VillageSettingEnums.TrapRepeatTimeMax, trapRepeatTimeMax },

                { VillageSettingEnums.CropScanEnable, cropScanEnable },
                { VillageSettingEnums.CropScanCenterX, cropScanCenterX },
                { VillageSettingEnums.CropScanCenterY, cropScanCenterY },
                { VillageSettingEnums.CropScanMaxDistance, cropScanMaxDistance },
                { VillageSettingEnums.CropScanMinCroplands, cropScanMinCroplands },
                { VillageSettingEnums.CropScanGapMinSeconds, cropScanGapMinSeconds },
                { VillageSettingEnums.CropScanGapMaxSeconds, cropScanGapMaxSeconds },
            };
            return settings;
        }

        public VillageSettingInput()
        {
            this.WhenAnyValue(vm => vm.Tribe.SelectedItem)
                .Select(x => x.Tribe)
                .Subscribe((tribe) =>
                {
                    BarrackTroop.ChangeTribe(BuildingEnums.Barracks, tribe);
                    StableTroop.ChangeTribe(BuildingEnums.Stable, tribe);
                    GreatBarrackTroop.ChangeTribe(BuildingEnums.GreatBarracks, tribe);
                    GreatStableTroop.ChangeTribe(BuildingEnums.GreatStable, tribe);
                    WorkshopTroop.ChangeTribe(BuildingEnums.Workshop, tribe);
                    DodgeTroopSlots.ChangeTribe(tribe);
                });
        }
    }
}