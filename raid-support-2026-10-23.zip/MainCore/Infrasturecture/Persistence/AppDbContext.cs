﻿using StronglyTypedIds;
using System.Collections.Immutable;

[assembly: StronglyTypedIdDefaults(backingType: StronglyTypedIdBackingType.Int, converters: StronglyTypedIdConverter.None)]

namespace MainCore.Infrasturecture.Persistence
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        #region table

        public DbSet<Account> Accounts { get; set; }
        public DbSet<AccountInfo> AccountsInfo { get; set; }
        public DbSet<Access> Accesses { get; set; }
        public DbSet<AccountSetting> AccountsSetting { get; set; }
        public DbSet<HeroItem> HeroItems { get; set; }
        public DbSet<Village> Villages { get; set; }
        public DbSet<Building> Buildings { get; set; }
        public DbSet<QueueBuilding> QueueBuildings { get; set; }
        public DbSet<Job> Jobs { get; set; }
        public DbSet<Storage> Storages { get; set; }
        public DbSet<VillageSetting> VillagesSetting { get; set; }
        public DbSet<Farm> FarmLists { get; set; }
        public DbSet<RaidListEntry> RaidListEntries { get; set; }
        public DbSet<ScoutedTargetGarrison> ScoutedTargetGarrisons { get; set; }

        #endregion table

        #region account setting

        public static readonly ImmutableDictionary<AccountSettingEnums, int> AccountDefaultSettings = new Dictionary<AccountSettingEnums, int>
        {
            {AccountSettingEnums.ClickDelayMin, 500 },
            {AccountSettingEnums.ClickDelayMax, 900 },
            {AccountSettingEnums.TaskDelayMin, 1000 },
            {AccountSettingEnums.TaskDelayMax, 1500 },
            {AccountSettingEnums.EnableAutoLoadVillageBuilding, 1 },
            {AccountSettingEnums.UseStartAllButton, 0 },
            {AccountSettingEnums.FarmIntervalMin, 540 },
            {AccountSettingEnums.FarmIntervalMax, 660 },
            {AccountSettingEnums.Tribe, 0 },
            {AccountSettingEnums.SleepTimeMin, 480 },
            {AccountSettingEnums.SleepTimeMax, 600 },
            {AccountSettingEnums.WorkTimeMin, 600 },
            {AccountSettingEnums.WorkTimeMax, 720 },
            {AccountSettingEnums.HeadlessChrome, 0 },
            {AccountSettingEnums.EnableAutoStartAdventure, 0 },
            {AccountSettingEnums.HammerVillageId, 0 },
            {AccountSettingEnums.HammerReservePercent, 50 },
            {AccountSettingEnums.OnlineHoursMask, OnlineHoursMaskAll },
            {AccountSettingEnums.MinHeroHealthPercent, 0 },
            {AccountSettingEnums.EnableAutoHeroRevive, 0 },
            {AccountSettingEnums.RaidListNextAllowedSendAtMinutes, 0 },
            {AccountSettingEnums.EnableRaidReport, 1 },
            {AccountSettingEnums.RaidReportLastId, 0 },
            {AccountSettingEnums.ScoutReportLastId, 0 },
            {AccountSettingEnums.RaidListSendGapMinSeconds, 30 },
            {AccountSettingEnums.RaidListSendGapMaxSeconds, 90 },
            {AccountSettingEnums.EnableCombatCheckOnRaidList, 0 },
            {AccountSettingEnums.EnableCombatCheckOnAttack, 0 },
            {AccountSettingEnums.CombatCheckMaxAgeHours, 12 },
            {AccountSettingEnums.CombatSafetyMarginPercent, 20 },
            {AccountSettingEnums.RaidListNextAllowedSendAtSeconds, 0 },
            {AccountSettingEnums.EnableAttackWake, 1 },
            {AccountSettingEnums.AttackWakeBeforeMinMinutes, 5 },
            {AccountSettingEnums.AttackWakeBeforeMaxMinutes, 10 },
            {AccountSettingEnums.AttackWakeAfterMinMinutes, 5 },
            {AccountSettingEnums.AttackWakeAfterMaxMinutes, 10 },
            {AccountSettingEnums.EnableScoutAutoAttack, 0 },
            {AccountSettingEnums.ScoutAutoAttackVillageId, 0 },
            {AccountSettingEnums.ScoutAutoAttackType, 0 },
            {AccountSettingEnums.ScoutAutoAttackTroop1, 0 },
            {AccountSettingEnums.ScoutAutoAttackTroop2, 0 },
            {AccountSettingEnums.ScoutAutoAttackTroop3, 0 },
            {AccountSettingEnums.ScoutAutoAttackTroop4, 0 },
            {AccountSettingEnums.ScoutAutoAttackTroop5, 0 },
            {AccountSettingEnums.ScoutAutoAttackTroop6, 0 },
            {AccountSettingEnums.ScoutAutoAttackTroop7, 0 },
            {AccountSettingEnums.ScoutAutoAttackTroop8, 0 },
            {AccountSettingEnums.ScoutAutoAttackTroop9, 0 },
            {AccountSettingEnums.ScoutAutoAttackTroop10, 0 },
            {AccountSettingEnums.EnableClaimDailyQuestReward, 1 },
        }.ToImmutableDictionary();

        // All 24 bits set (hour 0 .. hour 23) = no restriction, matches pre-existing behavior
        // for accounts that existed before this setting was introduced.
        public const int OnlineHoursMaskAll = (1 << 24) - 1;

        private List<AccountSettingEnums> GetMissingAccountSettings()
        {
            var defaultSettings = AccountDefaultSettings.Keys
                .AsEnumerable();
            var dbSettings = AccountsSetting
                .Select(x => x.Setting)
                .Distinct()
                .AsEnumerable();
            return defaultSettings.Except(dbSettings).ToList();
        }

        public void FillAccountSettings()
        {
            var missingSettings = GetMissingAccountSettings();
            if (missingSettings.Count == 0) return;

            var missingSettingsDict = missingSettings
                .Select(x => new
                {
                    Setting = x,
                    Value = AccountDefaultSettings[x],
                })
                .ToDictionary(x => x.Setting, x => x.Value);

            var ids = Accounts
                .Select(x => x.Id)
                .AsEnumerable();

            var settings = new List<AccountSetting>();

            foreach (var id in ids)
            {
                foreach (var (setting, value) in missingSettingsDict)
                {
                    settings.Add(new AccountSetting
                    {
                        AccountId = id,
                        Setting = setting,
                        Value = value,
                    });
                }
            }

            AddRange(settings);
            SaveChanges();
        }

        #endregion account setting

        #region village setting

        public static readonly ImmutableDictionary<VillageSettingEnums, int> VillageDefaultSettings = new Dictionary<VillageSettingEnums, int>
        {
            {VillageSettingEnums.UseHeroResourceForBuilding, 0 },
            {VillageSettingEnums.ApplyRomanQueueLogicWhenBuilding, 0 },
            {VillageSettingEnums.UseSpecialUpgrade, 0 },
            {VillageSettingEnums.CompleteImmediately, 0 },
            {VillageSettingEnums.Tribe, 0 },
            {VillageSettingEnums.TrainTroopEnable, 0 },
            {VillageSettingEnums.TrainTroopRepeatTimeMin, 120 },
            {VillageSettingEnums.TrainTroopRepeatTimeMax, 180 },
            {VillageSettingEnums.TrainWhenLowResource, 0 },
            {VillageSettingEnums.BarrackTroop, 0 },
            {VillageSettingEnums.BarrackAmountMin, 1 },
            {VillageSettingEnums.BarrackAmountMax, 10 },
            {VillageSettingEnums.StableTroop, 0 },
            {VillageSettingEnums.StableAmountMin, 1 },
            {VillageSettingEnums.StableAmountMax, 10 },
            {VillageSettingEnums.GreatBarrackTroop, 0 },
            {VillageSettingEnums.GreatBarrackAmountMin, 1 },
            {VillageSettingEnums.GreatBarrackAmountMax, 10 },
            {VillageSettingEnums.GreatStableTroop, 0 },
            {VillageSettingEnums.GreatStableAmountMin, 1 },
            {VillageSettingEnums.GreatStableAmountMax, 10 },
            {VillageSettingEnums.WorkshopTroop, 0 },
            {VillageSettingEnums.WorkshopAmountMin, 1 },
            {VillageSettingEnums.WorkshopAmountMax, 10 },

            {VillageSettingEnums.AutoNPCEnable, 0 },
            {VillageSettingEnums.AutoNPCOverflow, 0 },
            {VillageSettingEnums.AutoNPCGranaryPercent, 95 },
            {VillageSettingEnums.AutoNPCWood, 1 },
            {VillageSettingEnums.AutoNPCClay, 1 },
            {VillageSettingEnums.AutoNPCIron, 1 },
            {VillageSettingEnums.AutoNPCCrop, 0 },
            {VillageSettingEnums.AutoNPCReverse, 0 },

            {VillageSettingEnums.AutoSendCropEnable, 0 },
            {VillageSettingEnums.AutoSendCropGranaryPercent, 7 },
            {VillageSettingEnums.AutoSendCropSourceEnable, 0 },
            {VillageSettingEnums.AutoSendCropReservePercent, 50 },

            {VillageSettingEnums.AutoBalanceEnable, 0 },
            {VillageSettingEnums.AutoBalanceOverflowPercent, 90 },
            {VillageSettingEnums.AutoBalanceTargetPercent, 50 },

            {VillageSettingEnums.DodgeEnable, 0 },
            {VillageSettingEnums.DodgeTroopSlot, 1 },

            {VillageSettingEnums.DefendDonateEnable, 0 },
            {VillageSettingEnums.DodgeRaidEnable, 0 },

            {VillageSettingEnums.SmithyUpgradeEnable, 0 },
            {VillageSettingEnums.SmithyUpgradeTroopSlot, 1 },
            {VillageSettingEnums.SmithyUpgradeBusyUntilUnixTime, 0 },

            {VillageSettingEnums.DemolishEnable, 0 },
            {VillageSettingEnums.DemolishSourceLocation, 0 },
            {VillageSettingEnums.DemolishTargetBuildingType, 0 },

            {VillageSettingEnums.SupplyFromHammerEnable, 0 },
            {VillageSettingEnums.SupplyFromHammerTargetPercent, 50 },

            {VillageSettingEnums.SmallCelebrationEnable, 0 },
            {VillageSettingEnums.SmallCelebrationBusyUntilUnixTime, 0 },

            {VillageSettingEnums.OverflowToHammerEnable, 0 },
            {VillageSettingEnums.OverflowToHammerPercent, 90 },

            {VillageSettingEnums.DodgeTroopSlotsMask, 0 },
            {VillageSettingEnums.DodgeTargetX, 0 },
            {VillageSettingEnums.DodgeTargetY, 0 },
            {VillageSettingEnums.DodgeSendSecondsBeforeImpact, 30 },
            {VillageSettingEnums.DodgeRecallSecondsAfterSend, 50 },

            {VillageSettingEnums.AutoSettleEnable, 0 },
            {VillageSettingEnums.AutoSettleTargetX, 0 },
            {VillageSettingEnums.AutoSettleTargetY, 0 },
            {VillageSettingEnums.ExpansionSupplyReservePercent, 30 },
            {VillageSettingEnums.NeedExpansionWood, 0 },
            {VillageSettingEnums.NeedExpansionClay, 0 },
            {VillageSettingEnums.NeedExpansionIron, 0 },
            {VillageSettingEnums.NeedExpansionCrop, 0 },
            {VillageSettingEnums.AutoSettleSettlersReady, 0 },

            {VillageSettingEnums.AutoRefreshEnable, 0 },
            {VillageSettingEnums.AutoRefreshMin, 45 },
            {VillageSettingEnums.AutoRefreshMax, 75 },

            {VillageSettingEnums.AutoClaimQuestEnable, 0 },
            {VillageSettingEnums.CompleteImmediatelyTime, 20 },

            // Opt-out (default ON) - see ApplyBuildTemplateTask's own comment for why. This
            // dictionary entry is the proper long-term fix (MainViewModel calls
            // context.FillVillageSettings() at startup, backfilling this row for every
            // pre-existing village); ApplyBuildTemplateTask.CanStart's "row missing = enabled"
            // check and VillageSettingInput's GetValueOrDefault(..., 1) default stay in place
            // too as a defensive fallback for the window before that backfill has run.
            {VillageSettingEnums.AutoApplyBuildTemplateEnable, 1 },

            // Hero revival tiers 2/3 (2026-09-12, see HeroReviveTask/SupplyForReviveTask).
            {VillageSettingEnums.NeedReviveWood, 0 },
            {VillageSettingEnums.NeedReviveClay, 0 },
            {VillageSettingEnums.NeedReviveIron, 0 },
            {VillageSettingEnums.NeedReviveCrop, 0 },
            {VillageSettingEnums.ReviveSupplyReservePercent, 30 },
            {VillageSettingEnums.ReviveWaitingCycles, 0 },

            // Oasis Scout (2026-09-15). Defaults: off, 10-field scan radius, every 20-40
            // minutes, 3-8 troops sent to an empty oasis.
            {VillageSettingEnums.EnableOasisScout, 0 },
            {VillageSettingEnums.OasisScoutMaxDistance, 10 },
            {VillageSettingEnums.OasisScoutIntervalMin, 20 },
            {VillageSettingEnums.OasisScoutIntervalMax, 40 },
            {VillageSettingEnums.OasisScoutTroopSlot, 0 },
            {VillageSettingEnums.OasisScoutMinTroops, 3 },
            {VillageSettingEnums.OasisScoutMaxTroops, 8 },
            {VillageSettingEnums.OasisScoutHeroPowerThreshold, 100 },

            // Trap auto-build (2026-09-22). Off by default; 5-15 traps per run, rechecked
            // every 10-20 MINUTES (stored value * 60 = seconds, same convention as
            // TrainTroopRepeatTimeMin/Max above - shorter than troop training's default
            // because a trap batch itself only takes a few minutes in-game).
            {VillageSettingEnums.TrapEnable, 0 },
            {VillageSettingEnums.TrapAmountMin, 5 },
            {VillageSettingEnums.TrapAmountMax, 15 },
            {VillageSettingEnums.TrapRepeatTimeMin, 10 },
            {VillageSettingEnums.TrapRepeatTimeMax, 20 },

            // Crop oasis scan (2026-09-24). Off by default (one-shot trigger checkbox); center
            // (0|0) is just a harmless placeholder - the user always fills this in themselves
            // before ticking Enable. Max distance 15 fields, min 7 Croplands (the lowest of the
            // game's own bonus-oasis Croplands values: 7/9/15/18), 5-15 SECOND gap between tile
            // checks (not minutes - see VillageSettingEnums comment).
            {VillageSettingEnums.CropScanEnable, 0 },
            {VillageSettingEnums.CropScanCenterX, 0 },
            {VillageSettingEnums.CropScanCenterY, 0 },
            {VillageSettingEnums.CropScanMaxDistance, 15 },
            {VillageSettingEnums.CropScanMinCroplands, 7 },
            {VillageSettingEnums.CropScanGapMinSeconds, 5 },
            {VillageSettingEnums.CropScanGapMaxSeconds, 15 },
        }.ToImmutableDictionary();

        private List<VillageSettingEnums> GetMissingVillageSettings()
        {
            var defaultSettings = VillageDefaultSettings.Keys
                .AsEnumerable();
            var dbSettings = VillagesSetting
                .Select(x => x.Setting)
                .Distinct()
                .AsEnumerable();
            return defaultSettings.Except(dbSettings).ToList();
        }

        public void FillVillageSettings()
        {
            var missingSettings = GetMissingVillageSettings();
            if (missingSettings.Count == 0) return;

            var missingSettingsDict = missingSettings
                .Select(x => new
                {
                    Setting = x,
                    Value = VillageDefaultSettings[x],
                })
                .ToDictionary(x => x.Setting, x => x.Value);

            var ids = Villages
                .Select(x => x.Id)
                .AsEnumerable();

            var settings = new List<VillageSetting>();

            foreach (var id in ids)
            {
                foreach (var (setting, value) in missingSettingsDict)
                {
                    settings.Add(new VillageSetting
                    {
                        VillageId = id,
                        Setting = setting,
                        Value = value,
                    });
                }
            }

            AddRange(settings);
            SaveChanges();
        }

        public void FillVillageSettings(AccountId accountId, VillageId villageId)
        {
            var settings = new List<VillageSetting>();

            foreach (var (setting, value) in VillageDefaultSettings)
            {
                if (setting == VillageSettingEnums.Tribe)
                {
                    var tribe = AccountsSetting
                        .Where(x => x.AccountId == accountId.Value)
                        .Where(x => x.Setting == AccountSettingEnums.Tribe)
                        .Select(x => x.Value)
                        .FirstOrDefault();

                    settings.Add(new VillageSetting
                    {
                        VillageId = villageId.Value,
                        Setting = setting,
                        Value = tribe,
                    });
                    continue;
                }
                settings.Add(new VillageSetting
                {
                    VillageId = villageId.Value,
                    Setting = setting,
                    Value = value,
                });
            }

            AddRange(settings);
        }

        #endregion village setting

        #region schema patches

        // This project has no EF Core migrations (see MainViewModel.Load: EnsureCreatedAsync is
        // the only schema mechanism, and it only creates the schema for a brand-new/empty
        // database - on an existing user's DB it does nothing). RaidListEntry (added
        // 2026-08-18, for the Raid List feature) is a genuinely NEW TABLE, unlike every setting
        // added before it (those just added new AccountSettingEnums/VillageSettingEnums values
        // into the existing generic Setting/Value tables via Fill*Settings() above - no schema
        // change needed). Without this, every existing install would crash the first time
        // RaidListEntries is queried, since the table would simply never get created for them.
        //
        // Rather than hand-typing a CREATE TABLE statement (risking a mismatch with whatever EF
        // Core's own conventions actually produce - column types, constraint names, index
        // names), GenerateCreateScript() asks EF Core itself for the exact DDL it would use for
        // the full current model; this pulls out just the statement(s) that mention
        // RaidListEntries and runs those standalone, rewritten to be idempotent
        // (IF NOT EXISTS) so it's safe to call unconditionally on every startup.
        public void EnsureRaidListEntriesTableExists()
        {
            var fullScript = Database.GenerateCreateScript();
            var statements = fullScript.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

            foreach (var statement in statements)
            {
                if (!statement.Contains("\"RaidListEntries\"", StringComparison.Ordinal)) continue;

                var idempotent = statement switch
                {
                    _ when statement.Contains("CREATE TABLE", StringComparison.Ordinal)
                        => statement.Replace("CREATE TABLE", "CREATE TABLE IF NOT EXISTS"),
                    _ when statement.Contains("CREATE UNIQUE INDEX", StringComparison.Ordinal)
                        => statement.Replace("CREATE UNIQUE INDEX", "CREATE UNIQUE INDEX IF NOT EXISTS"),
                    _ when statement.Contains("CREATE INDEX", StringComparison.Ordinal)
                        => statement.Replace("CREATE INDEX", "CREATE INDEX IF NOT EXISTS"),
                    _ => statement,
                };

                Database.ExecuteSqlRaw(idempotent);
            }
        }

        // TroopAmountRangesJson (added 2026-08-22 for randomized-per-send troop amounts) is a
        // NEW COLUMN on a table that, for anyone who already used the Raid List feature between
        // 2026-08-18 and now, already exists - so EnsureRaidListEntriesTableExists() above is a
        // no-op for them (its CREATE TABLE IF NOT EXISTS only helps a table that doesn't exist
        // yet at all). Same "no EF Core migrations" constraint as that method; same fix shape:
        // check for the column by hand and ALTER TABLE it in if missing. A brand-new install's
        // table already has the column for free (it's part of the current model, so it's in
        // GenerateCreateScript()'s CREATE TABLE above) - this only ever does real work once per
        // existing database.
        public void EnsureRaidListEntriesTroopAmountRangesColumnExists()
        {
            var hasColumn = Database
                .SqlQueryRaw<string>("SELECT name FROM pragma_table_info('RaidListEntries') WHERE name = 'TroopAmountRangesJson'")
                .AsEnumerable()
                .Any();
            if (hasColumn) return;

            Database.ExecuteSqlRaw("ALTER TABLE \"RaidListEntries\" ADD COLUMN \"TroopAmountRangesJson\" TEXT NULL");
        }

        // ReportStatsJson (added 2026-09-19 for RaidReportTask) - same situation and same fix
        // shape as EnsureRaidListEntriesTroopAmountRangesColumnExists() right above: a NEW
        // COLUMN on a table that already exists for anyone who used the Raid List before, and
        // this project has no EF Core migrations. A brand-new install's table already has the
        // column (it is part of the model, so GenerateCreateScript() includes it).
        public void EnsureRaidListEntriesReportStatsColumnExists()
        {
            var hasColumn = Database
                .SqlQueryRaw<string>("SELECT name FROM pragma_table_info('RaidListEntries') WHERE name = 'ReportStatsJson'")
                .AsEnumerable()
                .Any();
            if (hasColumn) return;

            Database.ExecuteSqlRaw("ALTER TABLE \"RaidListEntries\" ADD COLUMN \"ReportStatsJson\" TEXT NULL");
        }

        // ScoutedTargetGarrisons (added 2026-09-27, combat-decision feature) - a genuinely NEW
        // TABLE, same situation and same GenerateCreateScript()-based fix shape as
        // EnsureRaidListEntriesTableExists() above (see that method's comment for why - no EF
        // Core migrations in this project).
        public void EnsureScoutedTargetGarrisonsTableExists()
        {
            var fullScript = Database.GenerateCreateScript();
            var statements = fullScript.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

            foreach (var statement in statements)
            {
                if (!statement.Contains("\"ScoutedTargetGarrisons\"", StringComparison.Ordinal)) continue;

                var idempotent = statement switch
                {
                    _ when statement.Contains("CREATE TABLE", StringComparison.Ordinal)
                        => statement.Replace("CREATE TABLE", "CREATE TABLE IF NOT EXISTS"),
                    _ when statement.Contains("CREATE UNIQUE INDEX", StringComparison.Ordinal)
                        => statement.Replace("CREATE UNIQUE INDEX", "CREATE UNIQUE INDEX IF NOT EXISTS"),
                    _ when statement.Contains("CREATE INDEX", StringComparison.Ordinal)
                        => statement.Replace("CREATE INDEX", "CREATE INDEX IF NOT EXISTS"),
                    _ => statement,
                };

                Database.ExecuteSqlRaw(idempotent);
            }
        }

        // IsDeadTarget (added 2026-09-20) - same situation/fix shape as the two column patches
        // above. INTEGER NOT NULL DEFAULT 0 (SQLite bool) so existing rows read as "not dead".
        public void EnsureRaidListEntriesDeadTargetColumnExists()
        {
            var hasColumn = Database
                .SqlQueryRaw<string>("SELECT name FROM pragma_table_info('RaidListEntries') WHERE name = 'IsDeadTarget'")
                .AsEnumerable()
                .Any();
            if (hasColumn) return;

            Database.ExecuteSqlRaw("ALTER TABLE \"RaidListEntries\" ADD COLUMN \"IsDeadTarget\" INTEGER NOT NULL DEFAULT 0");
        }

        #endregion schema patches
    }
}