# TODO.md — TravianBotSharp (Playwright branch)

Priorities: **P0** = breaks a defensive/time-critical feature; **P1** = wrong or unverified behavior; **P2** = latent
risk / cleanup; **P3** = ideas. Updated 2026-10-29.

## P0

- [ ] Add a guard test that fails on `By.XPath(<x>.XPath)` (needs source access; CI can grep the repo).

## Live-verification backlog (not defects - tick off from the next live log; kept separate so P0 stays "breaks a defensive feature")

- [ ] **Verify the 2026-10-29 changes live** (new; nothing compiled): (A) hero resources: `Use N Wood from hero inventory` is a multiple of 100 that never exceeds the need rounded up (400 needed -> 400, not 500), and a need that the hero stock still covers is no longer refused because of rounding; (B) a page stuck in "navigating" logs `trying again in 10s (attempt n of 6)` and after 6 in a row `Browser treated as closed: the page was still navigating ...` instead of looping silently.
- [ ] **Attack check missing from the 2026-10-28 22:38-23:59 log** (new): no `Attack check:` line in 81 min (about 16 expected) and no Update village line. The code is wired in both places (CustomServiceScopeFactory + RxQueue); the likely cause is the Account Setting "Attack check" box being off on that account (`CanStart` follows it). Tick it, then confirm `Attack check: no village is under attack.` every 4-6 min. Without it the only look-out is the village-list read around each task (longest gap in that log: 8.5 min).
- [ ] **Verify the 2026-10-28 evening build live** (new): (A) a plan whose slot holds another building logs `removed the job "..." - slot N holds X level L, not Y` and builds
  nothing (no hero resources used); the jobs behind it still run. (B) Oasis scout: after `sent hero alone` the same run logs `has animals, but the hero is already away this run - skipping`
  with no Send-troops page visit, and any failure line now names its reason. Also check the log for two unexplained stalls (see CHANGELOG) - if they repeat, note whether the PC was asleep.
- [ ] **Verify the 2026-10-28 browser-close fix live** (new): no more `Browser was closed mid-task` right after a task starts (5x in 96 min before). Expected new
  lines when a page is mid-navigation: `the page was still navigating, trying again in 10s` (Information); a real close now logs
  `Browser treated as closed: <message>` first - send that line if it still happens. Build first (nothing here was compiled).
- [ ] **Verify the 2026-10-27 evening build live** (new): (A) a crop-blocked plan queues a cropland upgrade first (log `queued a cropland upgrade as the first job`), or with no cropland left logs `building tasks suspended`; (B) the per-troop tables show the right troops for the tribe, an old config appears as one row, two troops with different intervals are trained in one visit and come back at their own times. Build first: nothing here was compiled.
- [ ] **Verify the 2026-10-27 Upgrade fix live** (new): a plan blocked by "Increase crop production." must log `blocked by the game ... Looking again at` once and
  then stay quiet for 2-3 h (no 16-second `Upgrade building` loop); an unreadable wait logs `could not read the time until enough resources`.
  Decide: should a crop-blocked plan let the village's OTHER jobs run (today they wait behind it)? Check the Account Setting "Attack check" box after any save (an
  unticked save removes the task).
- [ ] **Verify the 2026-10-26 training change live** (new): set a non-zero "not again before" for the Barracks of a village, then
  after a batch the log must show `next visit at` no earlier than that interval (no more 75-105 s revisits). With "Construction first"
  on and a plan short of resources: `Train troop ... construction first ... no training until` and the building actually gets built.
  Also `Balance resources in V: nothing to send (...)` replaces the silent "failed / Bot skip". Decide later: protect a SUPPLYING
  village's resources for another village's building (today only the village's own training is held).
- [ ] **Verify the 2026-10-25 evening fixes live** (new): after an adventure the log must show a real next run (not `Schedule next run at <now>`),
  and `Start adventure: nothing to start now, looking again at HH:mm` instead of the task vanishing; `Overflow to hammer in V: nothing
  worth sending ... next look at` replaces the silent "failed / Bot skip" loop (no Marketplace visit every ~80 s).
  Still unproven from the same log: Attack check actually starting Dodge/Defend on a real attack; hero-health lines (needs
  `MinHeroHealthPercent` > 0); Trapper/Smithy queue reads.
- [ ] **Verify the 2026-10-25 build live** (new; also: merchant sends are multiples of 750, a busy Barracks defers to queue end, Trapper queue markup still unchecked): `Attack check:` lines every 4-6 min and Dodge/Defend still starting on a real
  attack with auto refresh OFF; `Start adventure: hero health ...` repeating every ~30 min while the hero is hurt and an
  adventure starting once it is healthy; `Oasis scout: hero health ...` skip lines; `Train troop ... queue is busy` /
  `next visit at` lines, and `Trapper ... at its level's cap` once per ~2 h. If a queue is never read (`queue table on the
  page: False` for Smithy/Town hall, or no `busy` line for training), send a page dump of a Barracks/Trapper page WITH a
  running queue - the `table.under_progress` markup is an assumption.
- [ ] **Verify the Oasis scout fix live** (new 2026-10-24): no more `Timed out after 180 seconds` at `ToDorfCommand` in the
  Oasis scout; a failed navigation now logs "opening the Send troops page took longer than 45s" and skips. If
  "the tile dialog could not be closed" appears, send a page dump (the close button selector is from one real capture).
- [ ] **Verify Defend pass 2 live** (new 2026-10-24): after pass 1 the log must show `second pass ... scheduled for HH:mm:ss`,
  then `defending now (pass 2 ...)` ~15 min before impact. Also look for `Screenshots/*-resource-unreadable-*.html` (why wood
  reads -1) and send it.
- [ ] **Verify raid handling live** (new 2026-10-23, see CHANGELOG). Needs a real hostile raid on a village with Defend on:
  log must show `Incoming raid on … defending now`; with `DodgeRaidEnable` off Dodge must log `incoming movement(s) found
  but none to react to`. If a flag is on and the page has neither table, `Screenshots/*-no-incoming-*.html` is saved:
  send it. Also still missing: a capture of an ENEMY raid (the one seen was the user's own, troop counts visible).

## Verified live (kept for the record)

- [x] Dodge send / Recall on the Playwright build (SendTroopsCommand selectors + `TimeoutSeconds`): 2026-10-22 11:14-11:15 and 6 pairs on 2026-10-24, see CHANGELOG. Alliance donation: 2026-10-23. Start adventure keeps running after a Skip: 2026-10-28 23:08-23:53 (`nothing to start now, looking again at ...`).
- Closed items from the old P0 text (positional-XPath conversion in 8 more files, 2026-10-22) stay done; only the guard test above is open.

## P1

- [ ] **Recall can miss its 90 s window when the browser restarts** (live 2026-10-23 15:25-15:28, TS-3201). Dodge sent at
  :53, browser closed at :50 of the next minute, recall found no cancel button at 15:28:43. Ideas: recall earlier
  (setting `DodgeRecallSecondsAfterSend` 50 -> ~30-40), retry the recall quickly after a re-open instead of re-login first,
  and find why the browser closed (Click timeouts then "Browser was closed", 4x in 5 minutes). 2026-10-28: a likely cause was found and fixed in code (AccountTaskBehavior closed the browser on a transient "page is navigating" read error) - see P0; unconfirmed for the 10-23 click-timeout case.
- [ ] Wood read as -1 on the Barracks/after-train page (`StorageParser.GetWood`, node `l1`): get a capture of that page to find
  out why; the Defend donation now works around it (asks for "all").
- [ ] Dodge target (35|-5) is a ~9-18 min trip and an unoccupied oasis: troops left out when a recall fails will fight
  there. Consider a nearer/safer target (user setting, no code).

- [x] Recall verified live (2026-10-22, 10-23, 10-24); only the missed-window case after a browser restart (first item of P1) stays open.
- [x] OBSOLETE for Defend since 2026-10-22 (Defend donates instead of sending by merchant). Still relevant for Balance/Overflow/Supply tasks. Earlier: diagnostics added (Defend logged the raw merchant block + URL when it skipped). Waiting for the next attack's log to decide. **Defend resource send: "No free merchants" may be a parser false-negative** (`GetFreeMerchants` returns 0 for both "none free" and "not found/unparsable"; no fixture test exists for `SendResourceParser`). 2026-10-20 attack sent only
  crop=8 despite large stock. The `Defend send plan` line never printed on 10-21 because it skipped earlier. Log
  `GetFreeMerchants` raw value and merchants-on-the-way; confirm with a village that certainly has merchants home.
- [ ] Defend budget constants (`MinimumActionTimeSeconds = 25`, Barracks ~10–15 s, Marketplace ~15–20 s) are
  estimates. 10-21 data: training took ~3 s (17:47:38→41); Marketplace nav ~4 s. Re-tune.
- [ ] Oasis scout: when a send fails with Retry, the task tries the next oasis and wastes 3 min each time; make a
  failed send skip the oasis quickly and log it.
- [ ] Pause during a 180 s wait is the only way out (user pressed Pause at 17:38:53 and 17:50:54). Shorter waits
  (see P0.2) fix the cause.
- [ ] Combat-decision engine: reveal-parsing of a "troops" scout report against a non-zero garrison unverified
  live; Stage B (real Attack wiring) not done.
- [ ] ScoutAutoAttackTask, ClaimDailyQuestRewardTask: 2026-10-06/07 stall after the 25-point reward (waited on the
  50-point screen) — cause never found; re-test on Playwright.

- [ ] **Adventure after start** (2026-10-28 log): `could not read the adventure timer` 6 s after a started adventure (fallback 20-30 min works), difficulty prints `unknown` (`AdventureParser.GetAdventureDifficult` reads `tdList[3].FirstChild`, probably a whitespace node - unproven) and the distance carries hidden direction marks (`8.25`). Needs a page capture of the adventure list and of the page right after the click.
- [ ] **Hero inventory is the build budget** (2026-10-28 log): 16,300 resources in 81 min, clay ran out at 23:54. Training eats the village's own stock first and the hero tops up construction; "construction first" never triggers because `ConstructionHold` is only set on `MissingResource`. Decide: a hero reserve per resource (for Defend/Revive) or leave as is.

## P2

- [ ] Log noise (2026-10-28): the same WRN printed 2-3x in the same second (`Construction queue is full`, `Don't have enough ...`); a normal queue-full wait is reported as `Task ... failed`; `SaveVillageSettingCommand` is logged after every training visit although its dictionary is empty (no-op).

- [ ] "Construction first" hold is capped at 3 h but UpgradeBuilding can wait longer (A_1201: 4 h 19 min for a Granary) - training then runs between holds and eats the resources (user decision 2026-10-28: leave as is).
- [ ] After `Restart` (TaskManager.Clear) the DB flag `Village.IsUnderAttack` can remain true while Dodge/Defend tasks are
  gone; `UpdateVillageListCommand` / `UpdateStorageCommand` only start them for a NEWLY flagged village, so an attack that is
  already flagged is not handled. Needs a safe re-add (Dodge has no "already handled" memory, unlike Defend).
- [ ] Oasis scout also stops its plain-troop sends when the hero is hurt (user decision 2026-10-24); revisit if only hero sends
  should stop.

- [ ] Audit the other tab `Load(AccountId)` overrides (MapAnalysis, SyncAttack, EditAccount, Village, RaidList, WaveAttack,
  Farming, Debug) for `[Reactive]` property sets made on the task pool; marshal them with `RxApp.MainThreadScheduler`.
  Fixed so far: AccountSettingViewModel (2026-10-22).

- [ ] Unscoped village lookups (`Villages.FirstOrDefault(x => x.Id == ...)` without `AccountId`), re-counted 2026-10-29: 7 left - `UpdateStorageCommand:26`, `SendResourceCommand:90`, `DodgeTroopTask:74`, `DefendDonateTask:57`,
  `BalanceResourceTask:179`, `OverflowToHammerTask:136` and the dead `SendReinforcementCommand:22`. `HeroReviveTask`, `SupplyFromHammerTask` and `OverflowToHammerTask:52` are already scoped.
- [ ] `SendReinforcementCommand.cs` is dead code (CHANGELOG once said deleted).
- [ ] `SyncBridge.Run` only converts `PlaywrightException`; a `System.TimeoutException` from `Locator.*` in the
  adapter would escape as a raw exception. Mirror the `ChromeBrowser` handling.
- [x] `docs/ONBOARDING.md` said "Selenium" - fixed 2026-10-29 (`.github/copilot-instructions.md` was already clean).
- [ ] Regenerate `packages.lock.json` whenever packages change (CI restore fails otherwise).
- [ ] 2026-09-26 open observations (Selenium era, re-check on Playwright): TS32 login 180 s timeout (suspected
  night/"mobile version" page variant), TS12 hero-inventory item lookup 180 s (item type exhausted, no
  "genuinely absent" exit in the wait loop).

## P3 (ideas, not started)

- [ ] Auto Settle: ordered backup coordinate list.
- [ ] Raid List: dedupe on bulk add; edit Min/Max in place (today = delete + re-add, losing stats/schedule).
- [ ] Alliance "Attacks" report list as a raid-target source (oases + enemy villages) — paused by the user.
- [ ] Cross-village reinforcement (Phalanx, Druidrider, hero) arriving before impact, with wake window.
- [ ] Optional "sentinel" check-ins so an attack can be detected while the bot sleeps (user said no for now).

## Verification checklist after any defensive-feature change

1. Static checks + CI green. 2. Live: attack on a test village with `DodgeEnable` + `DefendDonateEnable` on.
3. Log must contain, in order: `Incoming attack … will send dodge troops`, `Defend … trained`, `Sent troops from
   village … arriving`, `Dodged … will recall`, `Recalled dodge troops`.
