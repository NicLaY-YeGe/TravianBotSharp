# TravianBotSharp (TBS)

[![alt text][image]][hyperlink]

[hyperlink]: https://discord.gg/mBa4f2K
[image]:https://discordapp.com/api/guilds/740829801446637601/widget.png?style=banner4

**TravianBotSharp** is a **free** Travian bot supports [Travian Official](https://www.travian.com).

## Main features

- Multi-account support
- Auto builder (support use resource from hero inventory)
- Auto start adventures
- Auto start farm lists
- Auto claim side quest
- Auto NPC
- Auto train troop (per troop: amount and interval, queue-aware)
- Defence: attack look-out, Dodge + Recall, Defend (train + alliance donation)
- Oasis scout, Raid List, Sync Attack, auto settle, hero revive, merchant balancing

## Tech specification

Currently, TBS only runs on Windows (WPF, .NET 8). Browser control uses Microsoft.Playwright (bundled Chromium).
